/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logreg;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author adlimams
 */
public final class User extends DBCon{
    
    public final boolean login_user(String username, String password) {
        
        String sql = "SELECT * FROM user";
        boolean succeed =  false;
        
        try (
                Connection conn = this.create_connection();
                PreparedStatement statement = conn.prepareStatement(sql);
                ResultSet resultSet = statement.executeQuery();
                )
        {
            
            while(resultSet.next()){
                
                String usn = resultSet.getString("username");
                String pw = resultSet.getString("password");
                
                if (username.equals(usn) && password.equals(pw)) {
                    succeed = true;
                }
            }
            
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        
        return succeed;
    }
    
    
    public final int get_saldo(String username){
        
        String sql = "SELECT jumlah_saldo FROM user WHERE username = '" + username + "'";
        int saldo = 0;
        
        try (
                Connection conn = this.create_connection();
                PreparedStatement st = conn.prepareStatement(sql);
                ResultSet rs = st.executeQuery();
                )
        {
            
            while(rs.next()){

                saldo = rs.getInt("jumlah_saldo");

            }
            
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        
        return saldo;
    }
    
    public final int get_id(String username){
        
        String sql = "SELECT id_user FROM user WHERE username = '" + username + "'";
        int id = 0;
        
        try (
                Connection conn = this.create_connection();
                PreparedStatement st = conn.prepareStatement(sql);
                ResultSet rs = st.executeQuery();
                )
        {
            
            while(rs.next()){

                id = rs.getInt("id_user");

            }
            
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        
        return id;
    }
}
