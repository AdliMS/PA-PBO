/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logreg;
import java.sql.*;
import java.util.concurrent.ThreadLocalRandom;
import javax.swing.table.DefaultTableModel;
import static logreg.ItemList.con;

/**
 *
 * @author ROG
 */
public class DBCon {
    
    private static final String DB_URL = "jdbc:mysql://localhost:3306/topup";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public final Connection create_connection() throws SQLException {
        
        Connection conn = null;
        
        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
        } catch (ClassNotFoundException ex) {
            System.out.println(ex);
        }
        
        return conn;
    }
    
    
    public final boolean login_admin(String username, String password) {
        
        String sql = "SELECT * FROM admin";
        boolean succeed =  false;
        
        try (
                Connection conn = this.create_connection();
                PreparedStatement statement = conn.prepareStatement(sql);
                ResultSet resultSet = statement.executeQuery();
                )
        {
            
            while(resultSet.next()){
                
                String usn = resultSet.getString("username");
                String pw = resultSet.getString("password");
                
                if (username.equals(usn) && password.equals(pw)) {
                    succeed = true;
                }
            }
            
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        
        return succeed;
    }
    
    public final void register(String username, String password) {
        
        int randomNum = ThreadLocalRandom.current().nextInt(100000, 999999 + 1);
        String sql = "INSERT INTO user (username, password, jumlah_saldo) VALUES (?, ?, ?)";
        
        try (Connection con = this.create_connection();
             PreparedStatement statement = con.prepareStatement(sql);
                ) 
        {
            statement.setString(1, username);
            statement.setString(2, password);
            statement.setInt(3, randomNum);
            
            int rowsAffected = statement.executeUpdate();
            System.out.println("Register berhasil");
            System.out.println("Rows affected : " + rowsAffected);
            
        } catch (SQLException ex){
            System.out.println(ex);
        }
    }
    

}
