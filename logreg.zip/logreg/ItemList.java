/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logreg;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author adlimams
 */
public class ItemList extends DBCon{
    
    static DBCon con;
    private int harga, stok;
    
    ItemList() {
        con = new DBCon();
    }
    
    public final void fill_table() {
        
        String sql = "SELECT diamond.jumlah, item.harga_item, item.stok, item.id_item FROM diamond INNER JOIN item ON diamond.id_item = item.id_item";
        DefaultTableModel tModel = (DefaultTableModel) MenuCRUD.jTable1.getModel();
        
        try (
                Connection c = con.create_connection();
                PreparedStatement ps = c.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                ) {
            
            while (rs.next()) {
            Object[] row = new Object[MenuCRUD.jTable1.getColumnCount()];
            row[0] = rs.getInt("id_item");
            row[1] = rs.getInt("jumlah");
            row[2] = rs.getInt("harga_item");
            row[3] = rs.getInt("stok");
            tModel.addRow(row);
        }
            
        } catch(Exception e) {
            System.out.println(e);
        }
        
    }
    
    public final void add_item(int jumlah, int harga, int stok) {
        
        try {
            Connection c = con.create_connection();
            
            // Create PrepareStatement object
            Statement stmt = c.createStatement();
            c.setAutoCommit(false);

            String sql1 = "INSERT INTO item (harga_item, stok, admin_id_admin) VALUES (" + harga + ", " + stok + ", 1)";
            stmt.addBatch(sql1);

            String sql2 = "INSERT INTO diamond (jumlah) VALUES (" + jumlah + ")";
            stmt.addBatch(sql2);

            //Create an int[] to hold returned values
            int[] count = stmt.executeBatch();

            //Explicitly commit statements to apply changes
            c.commit();
            
        } catch (SQLException ex) {
            Logger.getLogger(ItemList.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public final void update_item(int id, int jumlah, int harga, int stok) {
        
        try {
            Connection c = con.create_connection();
            
            // Create PrepareStatement object
            Statement stmt = c.createStatement();
            c.setAutoCommit(false);

            String sql1 = "UPDATE item SET harga_item = " + harga + ", stok = " + stok + " WHERE id_item = " + id;
            stmt.addBatch(sql1);

            String sql2 = "UPDATE diamond SET jumlah = " + jumlah + " WHERE diamond.id_item = " + id;
            stmt.addBatch(sql2);

            //Create an int[] to hold returned values
            int[] count = stmt.executeBatch();

            //Explicitly commit statements to apply changes
            c.commit();
            
        } catch (SQLException ex) {
            Logger.getLogger(ItemList.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public final void del_item(int id) {
        
        
        try {
            Connection c = con.create_connection();
            
            // Create PrepareStatement object
            Statement stmt = c.createStatement();
            c.setAutoCommit(false);

            String sql1 = "DELETE FROM diamond WHERE id_item = " + id;
            stmt.addBatch(sql1);

            String sql2 = "DELETE FROM item WHERE id_item = " + id;
            stmt.addBatch(sql2);

            //Create an int[] to hold returned values
            int[] count = stmt.executeBatch();

            //Explicitly commit statements to apply changes
            c.commit();
            
        } catch (SQLException ex) {
            Logger.getLogger(ItemList.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public final void refresh_table() {
        
        String sql = "SELECT diamond.jumlah, item.harga_item, item.stok, item.id_item FROM diamond INNER JOIN item on diamond.id_item = item.id_item";
        DefaultTableModel tModel = (DefaultTableModel) MenuCRUD.jTable1.getModel();
        
        try (
                Connection c = con.create_connection();
                PreparedStatement ps = c.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                ) {
            
            MenuCRUD.jTable1.setModel(tModel);
            
        } catch(Exception e) {
            System.out.println(e);
        }
    }
    
    public final void set_harga(int harga) {
        this.harga = harga;
    }
    
    public final void set_stok(int stok) {
        this.stok = stok;
    }
    
    public final int get_harga() {
        return this.harga;
    }
    
    public final int get_stok() {
        return this.stok;
    }
    
    public final int get_id_item() {
        
        String sql = "SELECT id_item FROM item";
        int id = 0;
        
        try (
                Connection conn = this.create_connection();
                PreparedStatement statement = conn.prepareStatement(sql);
                ResultSet resultSet = statement.executeQuery();
                )
        {
            
            while(resultSet.next()){
                
                id = Integer.parseInt(resultSet.getString("id_item"));
               
            }
            
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        
        return id;
    }

class Diamonds extends ItemList {
    
    int jumlah;
    
    Diamonds() {
        super();
    }
    
    public final void set_jumlah(int jumlah) {
        this.jumlah = jumlah;
    }
    
    public final int get_jumlah() {
        return this.jumlah;
    }
}

class WeeklyPass extends ItemList {
    
    
    WeeklyPass() {
        super();
    }
}

class TwilightPass extends ItemList {
    
    int level;
    
    TwilightPass() {
        super();
    }
    
    public final void set_level(int level) {
        this.level = level;
    }
    
}
}
